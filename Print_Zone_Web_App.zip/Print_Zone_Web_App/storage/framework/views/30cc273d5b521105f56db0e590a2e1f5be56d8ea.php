<?php $__env->startSection('content'); ?>
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <h2 class="card-title font-weight-bold text-primary">Print Settings</h2>
                <?php if($data['found']): ?>
                    <p class="card-description"><code class="text-success">Available Print Settings</code></p>
                <?php else: ?>
                    <p class="card-description"><code class="text-danger">No Print Setting is available</code></p>
                <?php endif; ?>
                <div class="row mt-2 mb-4 mr-1">
                    <button class="btn btn-info ml-sm-auto" data-toggle="modal" data-target="#create_print_setting_modal">Create Print Setting</button>
                </div>
                <?php if($data['found']): ?>
                    <table class="col-lg-12 table table-responsive">
                        <thead>
                        <tr>
                            <th > Setting ID</th>
                            <th > Max File Count</th>
                            <th > Max Upload File Size </th>
                            <th > Storing Location </th>
                            <th > Created at </th>
                            <th > Updated at </th>
                            <th > Edit </th>
                            <th > Delete </th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $data['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($all->setting_id); ?></td>
                                <td><?php echo e($all->max_file_count); ?></td>
                                <td><?php echo e($all->max_size_total); ?>  KB</td>
                                <td><?php echo e($all->storing_location); ?></td>
                                <td><?php echo e((new DateTime($all->created_at))->format("d-m-Y h:i A")); ?></td>
                                <td><?php echo e((new DateTime($all->updated_at))->format("d-m-Y h:i A")); ?></td>
                                <td>
                                    <button type="button" class="btn btn-warning btn-rounded btn-sm" data-toggle="modal" data-target="#edit_print_setting_modal" data-setting_id="<?php echo e($all->setting_id); ?>" data-max_file_count="<?php echo e($all->max_file_count); ?>" data-max_size_total="<?php echo e($all->max_size_total); ?>" data-storing_location="<?php echo e($all->storing_location); ?>">Edit</button>
                                </td>
                                <td>
                                    <form action="/delete_print_setting" method="post">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="setting_id" value="<?php echo e($all->setting_id); ?>">
                                        <button type="submit" class="btn btn-danger btn-rounded btn-sm">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>



    
    <!-- Modal -->
    <div class="modal fade" id="create_print_setting_modal" tabindex="-1" role="dialog" aria-labelledby="create_print_setting_modalTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="create_print_setting_modalTitle">Create New Print Setting</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="/create_print_setting" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        
                        <div class="form-group row">
                            <label for="c_max_file_count" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Max File Count')); ?></label>

                            <div class="col-md-6">
                                <input id="c_max_file_count" type="text" class="form-control" name="c_max_file_count" value="<?php echo e(old('c_max_file_count')); ?>"  autocomplete="title" autofocus required>
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label for="c_max_size_total" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Max Size Total')); ?></label>

                            <div class="col-md-6">
                                <input id="c_max_size_total" type="text" class="form-control" name="c_max_size_total" value="<?php echo e(old('c_max_size_total')); ?>"  autocomplete="title" autofocus required>
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label for="c_storing_location" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Storing Location')); ?></label>

                            <div class="col-md-6">
                                <input id="c_storing_location" type="text" class="form-control" name="c_storing_location" value="<?php echo e(old('c_storing_location')); ?>"  autocomplete="title" autofocus required>
                            </div>
                        </div>
                        
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-success">Create</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
    




    

    <div class="modal fade" id="edit_print_setting_modal" tabindex="-1" role="dialog" aria-labelledby="edit_print_setting_modalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="edit_print_setting_modalLabel">Edit Print Setting</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="/edit_print_setting" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" id="setting_id" name="setting_id" value="">
                        
                        <div class="form-group row">
                            <label for="max_file_count" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Max File Count')); ?></label>

                            <div class="col-md-6">
                                <input id="max_file_count" type="text" class="form-control" name="max_file_count" value="<?php echo e(old('max_file_count')); ?>"  autocomplete="title" autofocus required>
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label for="max_size_total" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Max Size Total')); ?></label>

                            <div class="col-md-6">
                                <input id="max_size_total" type="text" class="form-control" name="max_size_total" value="<?php echo e(old('max_size_total')); ?>"  autocomplete="title" autofocus required>
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label for="storing_location" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Storing Location')); ?></label>

                            <div class="col-md-6">
                                <input id="storing_location" type="text" class="form-control" name="storing_location" value=""  autocomplete="title" autofocus required>
                            </div>
                        </div>
                        
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-warning">Edit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>





<?php $__env->startSection('extra_js'); ?>
    <script>
        $('#edit_print_setting_modal').on('show.bs.modal', function (event) {

            var button = $(event.relatedTarget)
            var setting_id = button.data('setting_id')
            var max_file_count = button.data('max_file_count')
            var max_size_total = button.data('max_size_total')
            var storing_location = button.data('storing_location')
            var modal = $(this)


            modal.find('.modal-body #setting_id').val(setting_id)
            modal.find('.modal-body #max_file_count').val(max_file_count)
            modal.find('.modal-body #max_size_total').val(max_size_total)
            modal.find('.modal-body #storing_location').val(storing_location)
        })
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Print_Zone_Web_App\resources\views/admin/print_setting.blade.php ENDPATH**/ ?>