<?php $__env->startSection('content'); ?>
    <?php ($status = $data['status']); ?>
    <?php ($system_id = $data['system_id']); ?>
    <div class="container-fluid px-lg-4">
        <div class="row">
            <div class="col-sm-12">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="card">
                            <div class="card-body">
                                <h1 class="text-primary">Turn On/Off Whole System </h1>
                                <h3 class="mt-4">Current System Status :
                                    <?php if($status): ?>
                                    <span class="text-success">  On </span>
                                    <?php else: ?>
                                    <span class="text-danger">  off </span>
                                    <?php endif; ?>
                                </h3>
                                <div class="row">
                                    <form action="/on_off_action" method="post">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="status" value="<?php echo e($status); ?>">
                                        <input type="hidden" name="system_id" value="<?php echo e($system_id); ?>">
                                        <?php if($status): ?>
                                            <button type="submit" class="btn-lg btn-danger my-5 ml-3">Turn off</button>
                                        <?php else: ?>
                                            <button type="submit" class="btn-lg btn-success my-5 ml-3">Turn On</button>
                                        <?php endif; ?>

                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Print_Zone_Web_App\resources\views/admin/on_off_system.blade.php ENDPATH**/ ?>