<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Print Queue</h4>
                    <p class="card-description"> Description : <code>File to be Printed</code> </p>
                    <?php if($data['found']): ?>
                        <table class="col-lg-12 table table-responsive">
                            <thead>
                            <tr>
                                <th > # </th>
                                <th > File name </th>
                                <th > Page Count </th>
                                <th > Size </th>
                                <th > Upload Time </th>
                                <th > Action </th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php ($count = 0); ?>
                            <?php $__currentLoopData = $data['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(++$count); ?></td>
                                    <td>
                                        <?php if(strlen($p->file_name) > 80): ?>
                                            <?php echo e(substr($p->file_name, 0, 80)); ?>.....
                                        <?php else: ?>
                                            <?php echo e($p->file_name); ?>.pdf
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($p->pg_count); ?></td>
                                    <td><?php echo e(ceil($p->size/1024)); ?> mb</td>
                                    <td><?php echo e((new DateTime($p->created_at))->format("Y-m-d h:i A")); ?></td>
                                    <td>
                                        <form method="POST" action="<?php echo e(route('student.cancel_print')); ?>">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="file_id" value="<?php echo e($p->id); ?>">
                                            <input type="hidden" name="user_id" value="<?php echo e(auth()->user()->id); ?>">
                                            <input type="hidden" name="file_name" value="<?php echo e($p->file_name); ?>">
                                            <button class="btn btn-danger btn-rounded btn-sm">Cancel</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <h2 class="text-center text-warning my-5">No Files to Print ! </h2>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.student_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Print_Zone_Web_App\resources\views/student/print_queue.blade.php ENDPATH**/ ?>