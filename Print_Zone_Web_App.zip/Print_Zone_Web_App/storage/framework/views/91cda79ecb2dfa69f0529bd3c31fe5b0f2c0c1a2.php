<?php $__env->startSection('content'); ?>
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <h2 class="card-title font-weight-bold text-primary">Manage Admin</h2>
                <?php if($data['found']): ?>
                    <p class="card-description"><code class="text-success">Available Admins</code></p>
                <?php else: ?>
                    <p class="card-description"><code class="text-danger">No Admin is created till now</code></p>
                <?php endif; ?>
                <div class="row mt-2 mb-4 mr-1">
                    <button class="btn btn-info ml-sm-auto" data-toggle="modal" data-target="#create_admin_modal">Create New Admin</button>
                </div>
                <?php if($data['found']): ?>
                    <table class="col-lg-12 table table-responsive">
                        <thead>
                        <tr>
                            <th > Admin ID</th>
                            <th > Name </th>
                            <th > Email </th>
                            <th > Role </th>
                            <th > Status </th>
                            <th > Edit </th>
                            <th > Delete </th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $data['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($all->id); ?></td>
                                <td><?php echo e($all->name); ?></td>
                                <td><?php echo e($all->email); ?></td>
                                <td><?php echo e($all->role); ?></td>
                                <td>
                                    <?php if($all->status): ?>
                                        <span class="text-success">Active</span>
                                    <?php else: ?>
                                        <span class="text-danger">Disable</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <button type="button" class="btn btn-warning btn-rounded btn-sm" data-toggle="modal" data-target="#edit_admin_modal" data-user_id="<?php echo e($all->id); ?>" data-name="<?php echo e($all->name); ?>" data-email="<?php echo e($all->email); ?>" data-role="<?php echo e($all->role); ?>" data-status="<?php echo e($all->status); ?>">Edit</button>
                                </td>
                                <td>
                                    <form action="/delete_admin" method="post">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="user_id" value="<?php echo e($all->id); ?>">
                                        <button type="submit" class="btn btn-danger btn-rounded btn-sm">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>



    
    <!-- Modal -->
    <div class="modal fade" id="create_admin_modal" tabindex="-1" role="dialog" aria-labelledby="create_admin_modalTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="create_admin_modalTitle">Create New Admin</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="/create_admin" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        
                        <div class="form-group row">
                            <label for="c_user_id" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Admin ID')); ?></label>

                            <div class="col-md-6">
                                <input id="c_user_id" type="text" class="form-control" name="c_user_id" value="<?php echo e(old('c_user_id')); ?>"  autocomplete="title" autofocus required>
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label for="c_name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Admin Name')); ?></label>

                            <div class="col-md-6">
                                <input id="c_name" type="text" class="form-control" name="c_name" value="<?php echo e(old('c_name')); ?>"  autocomplete="title" autofocus required>
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label for="c_email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Email')); ?></label>

                            <div class="col-md-6">
                                <input id="c_email" type="text" class="form-control" name="c_email" value="<?php echo e(old('c_email')); ?>"  autocomplete="title" autofocus required>
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label for="c_password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>

                            <div class="col-md-6">
                                <input id="c_password" type="password" class="form-control" name="c_password" value="<?php echo e(old('c_password')); ?>"  autocomplete="title" autofocus required>
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label for="c_role" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Role')); ?></label>
                            <div class="col-md-6">
                                <select class="form-control" id="c_role" name="c_role">
                                    <option >----</option>
                                    <option value="super_admin">Super Admin</option>
                                    <option value="admin_1">Admin 1</option>
                                    <option value="admin_2">Admin 2</option>
                                    <option value="admin_3">Admin 3</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label for="c_status" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Status')); ?></label>
                            <div class="col-md-6">
                                <select class="form-control" id="c_status" name="c_status">
                                    <option >----</option>
                                    <option value="1">Active</option>
                                    <option value="0">Disable</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-success">Create</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
    




    

    <div class="modal fade" id="edit_admin_modal" tabindex="-1" role="dialog" aria-labelledby="edit_admin_modalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="edit_admin_modalLabel">Edit Admin</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="/edit_admin" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="user_id" value="">
                        
                        <div class="form-group row">
                            <label for="user_id" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Admin ID')); ?></label>

                            <div class="col-md-6">
                                <input id="user_id" type="text" class="form-control" name="user_id" value="<?php echo e(old('user_id')); ?>"  autocomplete="title" autofocus required>
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Admin Name')); ?></label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>"  autocomplete="title" autofocus required>
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Email')); ?></label>

                            <div class="col-md-6">
                                <input id="email" type="text" class="form-control" name="email" value="<?php echo e(old('email')); ?>"  autocomplete="title" autofocus required>
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label for="role" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Role')); ?></label>
                            <div class="col-md-6">
                                <select class="form-control" id="role" name="role">
                                    <option >----</option>
                                    <option value="super_admin">Super Admin</option>
                                    <option value="admin_1">Admin 1</option>
                                    <option value="admin_2">Admin 2</option>
                                    <option value="admin_3">Admin 3</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label for="status" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Status')); ?></label>
                            <div class="col-md-6">
                                <select class="form-control" id="status" name="status">
                                    <option >----</option>
                                    <option value="1">Active</option>
                                    <option value="0">Disable</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-warning">Edit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>





<?php $__env->startSection('extra_js'); ?>
    <script>
        $('#edit_admin_modal').on('show.bs.modal', function (event) {

            var button = $(event.relatedTarget)
            var user_id = button.data('user_id')
            var name = button.data('name')
            var email = button.data('email')
            var role = button.data('role')
            var status = button.data('status')
            var modal = $(this)

            console.log(role);

            modal.find('.modal-body #user_id').val(user_id)
            modal.find('.modal-body #name').val(name)
            modal.find('.modal-body #email').val(email)
            modal.find('.modal-body #role').val(role)
            modal.find('.modal-body #status').val(status)
        })
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Print_Zone_Web_App\resources\views/admin/manage_admin.blade.php ENDPATH**/ ?>