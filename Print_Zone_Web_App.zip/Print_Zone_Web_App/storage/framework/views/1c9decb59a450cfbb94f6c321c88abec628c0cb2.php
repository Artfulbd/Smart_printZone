<?php $__env->startSection('content'); ?>
    <div class="container-fluid px-lg-4">
        <div class="row">
            <div class="col-md-12 mt-lg-4 mt-4">
                <!-- Page Heading -->
                <div class="d-sm-flex align-items-center justify-content-between mb-4">
                    <h1 class="h3 mb-0 text-gray-800">Print PDF</h1>
                </div>
            </div>
            <div class="col-md-12">
                <div class="row">


                    

                    <div class="col-sm">
                        <div class="card" style="box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2), 0 6px 20px 0 rgba(0,0,0,0.19);">
                            <div class="card-body">
                                <form method="POST" action="/print_file_cmd" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    
                                    <div class="form-group row">
                                        <label for="first_name"
                                               class="col-md-4 col-form-label text-md-right display-3 font-weight-bold"><?php echo e(__('Upload File : ')); ?></label>

                                        <div class="col-md-6">
                                            <div class="custom-file">
                                                <input type="file" class="custom-file-input  <?php $__errorArgs = ['uploaded_file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="uploaded_file" name="uploaded_file" >
                                                <label class="custom-file-label" for="validatedCustomFile">Choose file...</label>
                                                <div class="invalid-feedback font-weight-bold"><?php echo e($errors->first('uploaded_file')); ?></div>
                                            </div>
                                        </div>
                                    </div>
                                    


                                    
                                    <div class="form-group row mb-0">
                                        <div class="col-md-6 offset-md-4">
                                            <button type="submit" class="btn btn-danger">
                                                <?php echo e(__('Print')); ?>

                                            </button>
                                        </div>
                                    </div>
                                    
                                </form>
                            </div>
                        </div>
                    </div>



                </div>
            </div>
        </div>

    </div>


<?php $__env->stopSection(); ?>




<?php $__env->startSection('filename_bootstrap_js'); ?>
    <script type="text/javascript">

        $('.custom-file input').change(function (e) {
            var files = [];
            for (var i = 0; i < $(this)[0].files.length; i++) {
                files.push($(this)[0].files[i].name);
            }
            $(this).next('.custom-file-label').html(files.join(', '));
        });

    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.student_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Print_Zone_Web_App\resources\views/student/print_pdf.blade.php ENDPATH**/ ?>